import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { CreateUtilisateurComponent } from './utilisateurs/create-utilisateur/create-utilisateur.component';
import { UtilisateurDetailsComponent } from './utilisateurs/utilisateur-details/utilisateur-details.component';
import { UtilisateursListComponent } from './utilisateurs/utilisateurs-list/utilisateurs-list.component';
import { CreateTypeplatComponent } from './typeplats/create-typeplat/create-typeplat.component';
import { TypeplatDetailsComponent } from './typeplats/typeplat-details/typeplat-details.component';
import { TypeplatsListComponent } from './typeplats/typeplat-list/typeplats-list.component';
import { CreateMenuComponent } from './menu/create-menu/create-menu.component';
import { MenuDetailsComponent } from './menu/menu-details/menu-details.component';
import { MenusListComponent } from './menu/menu-list/menus-list.component';
import { AppRoutingModule } from './app-routing.module';
import {DetailsUploadComponent} from './uploads/details-upload/details-upload.component';
import {FormUploadComponent} from './uploads/form-upload/form-upload.component';
import {ListUploadComponent} from './uploads/list-upload/list-upload.component';
import {UploadFileService} from './uploads/upload-file.service';

@NgModule({
  declarations: [
    AppComponent,
    CreateUtilisateurComponent,
    UtilisateurDetailsComponent,
    UtilisateursListComponent,
    CreateTypeplatComponent,
    TypeplatDetailsComponent,
    TypeplatsListComponent,
    CreateMenuComponent,
    MenuDetailsComponent,
    MenusListComponent,
    DetailsUploadComponent,
    FormUploadComponent,
    ListUploadComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
