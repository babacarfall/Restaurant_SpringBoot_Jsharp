import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { TypeplatService } from '../typeplat.service';
import { Typeplat } from '../typeplat';

@Component({
  selector: 'typeplats-list',
  templateUrl: './typeplats-list.component.html',
  styleUrls: ['./typeplats-list.component.css']
})
export class TypeplatsListComponent implements OnInit {

  typeplats: Observable<Typeplat[]>;

  constructor(private typeplatService: TypeplatService) { }

  ngOnInit() {
    this.reloadData();
  }


  reloadData() {
    this.typeplats = this.typeplatService.getTypeplatsList();
  }
}
