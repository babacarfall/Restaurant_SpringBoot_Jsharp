import { Component, OnInit, Input } from '@angular/core';
import { UtilisateurService } from '../utilisateur.service';
import { Utilisateur } from '../utilisateur';

import { UtilisateursListComponent } from '../utilisateurs-list/utilisateurs-list.component';

@Component({
  selector: 'utilisateur-details',
  templateUrl: './utilisateur-details.component.html',
  styleUrls: ['./utilisateur-details.component.css']
})
export class UtilisateurDetailsComponent implements OnInit {

  @Input() utilisateur: Utilisateur;

  constructor(private utilisateurService: UtilisateurService, private listComponent: UtilisateursListComponent) { }

  ngOnInit() {
  }

  updateActive(isActive: boolean) {
    this.utilisateurService.updateUtilisateur(this.utilisateur.id,
      { utilisateur: this.utilisateur.username, pwd: this.utilisateur.password, active: isActive })
      .subscribe(
        data => {
          console.log(data);
          this.utilisateur = data as Utilisateur;
        },
        error => console.log(error));
  }

  deleteUtilisateur() {
    this.utilisateurService.deleteUtilisateur(this.utilisateur.id)
      .subscribe(
        data => {
          console.log(data);
          this.listComponent.reloadData();
        },
        error => console.log(error));
  }
}
