import { Component, OnInit } from '@angular/core';

import { Utilisateur } from '../utilisateur';
import { UtilisateurService } from '../utilisateur.service';

@Component({
  selector: 'create-utilisateur',
  templateUrl: './create-utilisateur.component.html',
  styleUrls: ['./create-utilisateur.component.css']
})
export class CreateUtilisateurComponent implements OnInit {

  utilisateur: Utilisateur = new Utilisateur();
  submitted = false;

  constructor(private utilisateurService: UtilisateurService) { }

  ngOnInit() {
  }

  newUtilisateur(): void {
    this.submitted = false;
    this.utilisateur = new Utilisateur();
  }

  save() {
    this.utilisateurService.createUtilisateur(this.utilisateur)
      .subscribe(data => console.log(data), error => console.log(error));
    this.utilisateur = new Utilisateur();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
