export class Typeplat {
    id: number;
    nom: string;
}
