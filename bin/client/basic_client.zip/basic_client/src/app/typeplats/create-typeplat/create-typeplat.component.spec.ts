import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateTypeplatComponent } from './create-typeplat.component';

describe('CreateTypeplatComponent', () => {
  let component: CreateTypeplatComponent;
  let fixture: ComponentFixture<CreateTypeplatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateTypeplatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTypeplatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
