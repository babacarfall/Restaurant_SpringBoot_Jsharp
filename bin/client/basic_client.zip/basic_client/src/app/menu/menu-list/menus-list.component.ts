import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { MenuService } from '../menu.service';
import { Menu } from '../menu';

@Component({
  selector: 'menus-list',
  templateUrl: './menus-list.component.html',
  styleUrls: ['./menus-list.component.css']
})
export class MenusListComponent implements OnInit {

  menus: Observable<Menu[]>;

  constructor(private menuService: MenuService) { }

  ngOnInit() {
    this.reloadData();
  }


  reloadData() {
    this.menus = this.menuService.getMenusList();
  }
}
