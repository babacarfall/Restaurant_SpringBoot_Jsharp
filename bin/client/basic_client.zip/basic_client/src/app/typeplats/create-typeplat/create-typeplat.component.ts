import { Component, OnInit } from '@angular/core';

import { Typeplat } from '../typeplat';
import { TypeplatService } from '../typeplat.service';

@Component({
  selector: 'create-typeplat',
  templateUrl: './create-typeplat.component.html',
  styleUrls: ['./create-typeplat.component.css']
})
export class CreateTypeplatComponent implements OnInit {

  typeplat: Typeplat = new Typeplat();
  submitted = false;

  constructor(private typeplatService: TypeplatService) { }

  ngOnInit() {
  }

  newTypeplat(): void {
    this.submitted = false;
    this.typeplat = new Typeplat();
  }

  save() {
    this.typeplatService.createTypeplat(this.typeplat)
      .subscribe(data => console.log(data), error => console.log(error));
    this.typeplat = new Typeplat();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
