var app = angular.module('app', []);

//#######################
//JSA CONTROLLER
//#######################

app.controller('jsaController', function($scope, $http, $location) {
	$scope.listTypeplats = [];
	
	// $scope.getAllCustomer = 
	function getAllTypeplat(){
		// get URL
  var url = 'http://localhost:8080/api/typeplat';
		
		// do getting
		$http.get(url).then(function (response) {
			$scope.getDivAvailable = true;
			$scope.listTypeplats = response.data;
			
			// initialize selectedCustomer for Select Boxes Using ng-options
			$scope.selectedTypeplat = $scope.listTypeplats[0]; 
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	}
	
	getAllTypeplat();
});