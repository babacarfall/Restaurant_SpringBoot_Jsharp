import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { UtilisateurService } from '../utilisateur.service';
import { Utilisateur } from '../utilisateur';

@Component({
  selector: 'utilisateurs-list',
  templateUrl: './utilisateurs-list.component.html',
  styleUrls: ['./utilisateurs-list.component.css']
})
export class UtilisateursListComponent implements OnInit {

  utilisateurs: Observable<Utilisateur[]>;

  constructor(private utilisateurService: UtilisateurService) { }

  ngOnInit() {
    this.reloadData();
  }


  reloadData() {
    this.utilisateurs = this.utilisateurService.getUtilisateursList();
  }
}
