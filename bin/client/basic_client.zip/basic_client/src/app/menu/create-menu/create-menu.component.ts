import { Component, OnInit } from '@angular/core';

import { Menu } from '../menu';
import { MenuService } from '../menu.service';

@Component({
  selector: 'create-menu',
  templateUrl: './create-menu.component.html',
  styleUrls: ['./create-menu.component.css']
})
export class CreateMenuComponent implements OnInit {

  menu: Menu = new Menu();
  submitted = false;

  constructor(private menuService: MenuService) { }

  ngOnInit() {
  }

  newMenu(): void {
    this.submitted = false;
    this.menu = new Menu();
  }

  save() {
    this.menuService.createMenu(this.menu)
      .subscribe(data => console.log(data), error => console.log(error));
    this.menu = new Menu();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
