import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TypeplatDetailsComponent } from './typeplat-details.component';

describe('TypeplatDetailsComponent', () => {
  let component: TypeplatDetailsComponent;
  let fixture: ComponentFixture<TypeplatDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypeplatDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeplatDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
