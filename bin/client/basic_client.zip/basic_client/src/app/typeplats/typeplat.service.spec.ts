import { TestBed, inject } from '@angular/core/testing';

import { TypeplatService } from './typeplat.service';

describe('TypeplatService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TypeplatrService]
    });
  });

  it('should be created', inject([TypeplatService], (service: TypeplatService) => {
    expect(service).toBeTruthy();
  }));
});
