import { Component, OnInit, Input } from '@angular/core';
import { MenuService } from '../menu.service';
import { Menu } from '../menu';

import { MenusListComponent } from '../menu-list/menus-list.component';

@Component({
  selector: 'menu-details',
  templateUrl: './menu-details.component.html',
  styleUrls: ['./menu-details.component.css']
})
export class MenuDetailsComponent implements OnInit {

  @Input() menu: Menu;

  constructor(private menuService: MenuService, private listComponent: MenusListComponent) { }

  ngOnInit() {
  }

  updateActive(isActive: boolean) {
    this.menuService.updateMenu(this.menu.id,
      { desc: this.menu.desc, photo: this.menu.photo,plat: this.menu.plat,prix: this.menu.prix})
      .subscribe(
        data => {
          console.log(data);
          this.menu = data as Menu;
        },
        error => console.log(error));
  }

  deleteMenu() {
    this.menuService.deleteMenu(this.menu.id)
      .subscribe(
        data => {
          console.log(data);
          this.listComponent.reloadData();
        },
        error => console.log(error));
  }
}
