import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TypeplatsListComponent } from './typeplats-list.component';

describe('TypeplatsListComponent', () => {
  let component: TypeplatsListComponent;
  let fixture: ComponentFixture<TypeplatsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypeplatsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeplatsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
