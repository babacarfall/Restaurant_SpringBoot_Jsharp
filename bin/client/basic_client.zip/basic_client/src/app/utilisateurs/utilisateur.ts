export class Utilisateur {
    id: number;
    username: string;
    password: string;
}
