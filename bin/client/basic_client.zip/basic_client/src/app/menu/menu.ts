export class Menu {
   id: string;
   desc: string;
   photo: string;
   plat: string;
   prix: string ;
   
   }
