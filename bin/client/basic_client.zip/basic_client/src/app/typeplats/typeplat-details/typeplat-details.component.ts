import { Component, OnInit, Input } from '@angular/core';
import { TypeplatService } from '../typeplat.service';
import { Typeplat } from '../typeplat';

import { TypeplatsListComponent } from '../typeplat-list/typeplats-list.component';

@Component({
  selector: 'typeplat-details',
  templateUrl: './typeplat-details.component.html',
  styleUrls: ['./typeplat-details.component.css']
})
export class TypeplatDetailsComponent implements OnInit {

  @Input() typeplat: Typeplat;

  constructor(private typeplatService: TypeplatService, private listComponent: TypeplatsListComponent) { }

  ngOnInit() {
  }

  updateActive(isActive: boolean) {
    this.typeplatService.updateTypeplat(this.typeplat.id,
      { typeplat: this.typeplat.nom })
      .subscribe(
        data => {
          console.log(data);
          this.typeplat = data as Typeplat;
        },
        error => console.log(error));
  }

  deleteTypeplat() {
    this.typeplatService.deleteTypeplat(this.typeplat.id)
      .subscribe(
        data => {
          console.log(data);
          this.listComponent.reloadData();
        },
        error => console.log(error));
  }
}
